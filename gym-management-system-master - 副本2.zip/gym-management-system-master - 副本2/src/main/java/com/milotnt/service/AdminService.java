package com.milotnt.service;

import com.milotnt.pojo.Admin;

/**
 * @author MiloTnT [milotntspace@gmail.com]
 * @date 2021/8/11
 */

public interface AdminService {

    //管理员登录
    Admin adminLogin(Admin admin);

}
